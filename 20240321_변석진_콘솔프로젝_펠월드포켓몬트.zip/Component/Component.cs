﻿namespace ConsoleGameProject
{
    public class Component
    {

    }
}
