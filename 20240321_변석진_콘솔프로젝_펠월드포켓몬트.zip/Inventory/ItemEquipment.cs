﻿namespace ConsoleGameProject
{
    public class ItemEquipment
    {
    }
}
