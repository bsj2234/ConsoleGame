﻿namespace ConsoleGameProject
{
    internal class ItemWeapon
    {
    }
}
