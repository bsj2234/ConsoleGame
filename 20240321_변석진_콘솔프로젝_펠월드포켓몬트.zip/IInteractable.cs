﻿namespace ConsoleGameProject
{
    public interface IInteractable
    {
        public void Interact();
    }
}
