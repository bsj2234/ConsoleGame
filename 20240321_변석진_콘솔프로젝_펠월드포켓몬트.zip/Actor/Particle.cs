﻿using MyData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//namespace ConsoleGameProject
//{
//    //public class Particle : Actor
//    {
//        //public Particle(Vec2 position, Vec2 size, double LifeTime) : base("", position, Vec2.Unit, true)
//        //{
//        //    Task lifeAsync = Task.Run(() =>
//        //    {
//        //        int lifeTime = 0;
//        //        while (lifeTime < LifeTime) 
//        //        {
//        //        }
//        //        Destroy();
//        //    });

//        //    RenderC = '@';
//        //}

//        //private void ParticleMove()
//        //{

//        //}
//    }
//}
